package com.ssc.controller.validator;

public class NullAbleValiadator {

}
