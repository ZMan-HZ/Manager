package com.ssc.beans;

public class ProjectStatusCustom  extends ProjectStatus{

}
