package com.ssc.beans;

public class NaviBeanCustom extends NaviBean{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
