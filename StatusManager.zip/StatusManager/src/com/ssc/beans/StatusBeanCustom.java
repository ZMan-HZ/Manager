package com.ssc.beans;

import java.io.Serializable;
import java.util.List;

/**
 *  @Description: 扩展类 
 * @author e6332s29
 *
 */
public class StatusBeanCustom  extends StatusBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<String> statusInforList;

	private List<String> testCaseList;
	private String reviewedTag;
	
	

	public String getReviewedTag() {
		return reviewedTag;
	}

	public void setReviewedTag(String reviewedTag) {
		this.reviewedTag = reviewedTag;
	}

	public List<String> getTestCaseList() {
		return testCaseList;
	}

	public void setTestCaseList(List<String> testCaseList) {
		this.testCaseList = testCaseList;
	}

	public List<String> getStatusInforList() {
		return statusInforList;
	}

	public void setStatusInforList(List<String> statusInforList) {
		this.statusInforList = statusInforList;
	}
	
	
	
}
