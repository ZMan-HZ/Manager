package com.ssc.beans;

import java.io.Serializable;

public class StatusBasicBeanCustom  extends StatusBasicBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
