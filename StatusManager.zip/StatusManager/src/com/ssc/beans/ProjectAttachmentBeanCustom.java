package com.ssc.beans;

import java.io.Serializable;

public class ProjectAttachmentBeanCustom  extends ProjectAttachmentBean implements Serializable{

}
