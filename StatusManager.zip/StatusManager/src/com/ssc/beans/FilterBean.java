package com.ssc.beans;

import java.util.Map;

public class FilterBean {
	private String owner;
	private String prodDate;
	private String prodDateOrigin;
	private String prodDateNew;
	private String projectName;
	private String isDelete;
	private String isClose;
	private String isOnlyShowLatestInfo;
	private String reverse;
	private String[] jobStatus;
	private String hideOrder;
	private String hideLeader;
	private String hideOwner;
	private String hideStatusInfo;
	private String hideDocument;
	private String hideProdDate;
	private String hideActivity;
	private String hidePercent;
	private String hideJobStatus;
	private String hideComment;
	private String hideCopyItem;
	private String isFilter;
//	private String isNewInsert; //  contorl Status Infor Column set font blue;
	private Map<String,String> filterStatus;
	
	
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getProdDate() {
		return prodDate;
	}
	public void setProdDate(String prodDate) {
		this.prodDate = prodDate;
	}
	public String getProdDateOrigin() {
		return prodDateOrigin;
	}
	public void setProdDateOrigin(String prodDateOrigin) {
		this.prodDateOrigin = prodDateOrigin;
	}
	public String getProdDateNew() {
		return prodDateNew;
	}
	public void setProdDateNew(String prodDateNew) {
		this.prodDateNew = prodDateNew;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getIsDelete() {
		return isDelete;
	}
	public void setIsDelete(String isDelete) {
		this.isDelete = isDelete;
	}
	public String getIsClose() {
		return isClose;
	}
	public void setIsClose(String isClose) {
		this.isClose = isClose;
	}
	public String getIsOnlyShowLatestInfo() {
		return isOnlyShowLatestInfo;
	}
	public void setIsOnlyShowLatestInfo(String isOnlyShowLatInfo) {
		this.isOnlyShowLatestInfo = isOnlyShowLatInfo;
	}
	public String getReverse() {
		return reverse;
	}
	public void setReverse(String reverse) {
		this.reverse = reverse;
	}
	
	public String[] getJobStatus() {
		return jobStatus;
	}
	public void setJobStatus(String[] jobStatus) {
		this.jobStatus = jobStatus;
	}
	public String getHideOrder() {
		return hideOrder;
	}
	public void setHideOrder(String hideOrder) {
		this.hideOrder = hideOrder;
	}
	public String getHideLeader() {
		return hideLeader;
	}
	public void setHideLeader(String hideLeader) {
		this.hideLeader = hideLeader;
	}
	public String getHideOwner() {
		return hideOwner;
	}
	public void setHideOwner(String hideOwner) {
		this.hideOwner = hideOwner;
	}
	public String getHideStatusInfo() {
		return hideStatusInfo;
	}
	public void setHideStatusInfo(String hideStatusInfo) {
		this.hideStatusInfo = hideStatusInfo;
	}
	public String getHideDocument() {
		return hideDocument;
	}
	public void setHideDocument(String hideDocument) {
		this.hideDocument = hideDocument;
	}
	public String getHideProdDate() {
		return hideProdDate;
	}
	public void setHideProdDate(String hideProdDate) {
		this.hideProdDate = hideProdDate;
	}
	public String getHideActivity() {
		return hideActivity;
	}
	public void setHideActivity(String hideActivity) {
		this.hideActivity = hideActivity;
	}
	public String getHidePercent() {
		return hidePercent;
	}
	public void setHidePercent(String hidePercent) {
		this.hidePercent = hidePercent;
	}
	public String getHideJobStatus() {
		return hideJobStatus;
	}
	public void setHideJobStatus(String hideJobStatus) {
		this.hideJobStatus = hideJobStatus;
	}
	public String getHideComment() {
		return hideComment;
	}
	public void setHideComment(String hideComment) {
		this.hideComment = hideComment;
	}
	public String getHideCopyItem() {
		return hideCopyItem;
	}
	public void setHideCopyItem(String hideCopyItem) {
		this.hideCopyItem = hideCopyItem;
	}
	public String getIsFilter() {
		return isFilter;
	}
	public void setIsFilter(String isFilter) {
		this.isFilter = isFilter;
	}
//	public String getIsNewInsert() {
//		return isNewInsert;
//	}
//	public void setIsNewInsert(String isNewInsert) {
//		this.isNewInsert = isNewInsert;
//	}
	public Map<String, String> getFilterStatus() {
		return filterStatus;
	}
	public void setFilterStatus(Map<String, String> filterStatus) {
		this.filterStatus = filterStatus;
	}

	
	
	
	
	
	
	

}
