package com.ssc.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import com.ssc.beans.StatusBasicBeanCustom;
import com.ssc.beans.StatusBeanCustom;
import com.ssc.beans.StatusBeanVo;
import com.ssc.mapper.StatusMapper;
import com.ssc.service.StatusService;


public class StatusServiceImpl  implements StatusService{

	@Autowired
	private StatusMapper statusMapper;
	
	
	@Override
	public List<StatusBeanCustom> getProjectNames() throws Exception {
		
		return statusMapper.getProjectNames();
	}

	@Override
	public List<StatusBasicBeanCustom> getProjectStausByGroupID(Integer groupID) throws Exception {
		return statusMapper.getProjectStausByGroupID(groupID);
	}

	@Override
	public List<StatusBeanCustom> getStatusByMultiParam(StatusBeanVo statusBeanVo) throws Exception {
		return statusMapper.getStatusByMultiParam(statusBeanVo);
	}

	
	
}
	
