package com.ssc.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import com.ssc.beans.ProjectAttachmentBean;
import com.ssc.beans.ProjectAttachmentQueryVo;
import com.ssc.mapper.DownloadFileMapper;
import com.ssc.service.DownloadFileService;

public class DownloadFileServiceImpl implements DownloadFileService{

	
	@Autowired
	DownloadFileMapper downloadFileMapper;
	
	@Override
	public List<ProjectAttachmentBean> getAllFilesByMultiParam(ProjectAttachmentQueryVo projectAttachmentQueryVo)throws Exception {
		return downloadFileMapper.getAllFilesByMultiParam(projectAttachmentQueryVo);
	}

	@Override
	public List<ProjectAttachmentBean> getFilesByProjectID(Integer projectStatusId)throws Exception {
		return downloadFileMapper.getFilesByProjectID(projectStatusId);
	}

	@Override
	public ProjectAttachmentBean getFilesByID(Integer id) throws Exception {
		return downloadFileMapper.getFilesByID(id);
	}

}
