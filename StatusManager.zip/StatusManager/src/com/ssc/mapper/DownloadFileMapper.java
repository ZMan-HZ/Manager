package com.ssc.mapper;

import java.util.List;

import com.ssc.beans.ProjectAttachmentBean;
import com.ssc.beans.ProjectAttachmentQueryVo;

public interface DownloadFileMapper {

	
	
	public List<ProjectAttachmentBean> getAllFilesByMultiParam(ProjectAttachmentQueryVo projectAttachmentQueryVo) throws Exception;
	public List<ProjectAttachmentBean> getFilesByProjectID(Integer projectStatusId)  throws Exception;
	public ProjectAttachmentBean getFilesByID(Integer id) throws Exception;
	
	
	
}
