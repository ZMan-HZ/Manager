package com.ssc.mapper;

import java.util.List;
import com.ssc.beans.ProjectAttachmentBean;
import com.ssc.beans.ProjectAttachmentQueryVo;
import com.ssc.beans.StatusBasicBeanCustom;
import com.ssc.beans.StatusBean;
import com.ssc.beans.StatusBeanCustom;
import com.ssc.beans.StatusBeanVo;
import com.ssc.beans.User;

public interface StatusMapper {

	
	public StatusBean getStatusByID(Integer id) throws Exception;
	public List<StatusBean> getStatusByJobStatus(StatusBeanVo statusBeanVo) throws Exception;
	public List<User> getAllUsers() throws Exception;
	public List<ProjectAttachmentBean> getFileByID(Integer id) throws Exception;
	public List<StatusBean> getStatusByIDList(StatusBeanVo statusBeanVo) throws Exception;
	
	public List<StatusBeanCustom> getStatusByMultiParam(StatusBeanVo statusBeanVo) throws Exception;
	
	public List<StatusBean> getProjectCommentsList(StatusBeanVo statusBeanVo) throws Exception;
	public StatusBean getProjectComment(StatusBeanVo statusBeanVo) throws Exception;
	
	public List<StatusBeanCustom> getProjectNames() throws Exception;
	public List<StatusBasicBeanCustom> getProjectStausByGroupID(Integer groupID) throws Exception;
	
	
	public void updateUserByName(String userName,User user) throws Exception;
	public void insertStatusRecord(StatusBean statusBean) throws Exception;
	public void updateStatusRecordByID(Integer id,StatusBean statusBean) throws Exception;
	

	
	
}
