package com.ssc.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.ssc.beans.UserCustom;
import com.ssc.service.LoginService;

@Controller
public class LoginController {

	@Autowired
	private LoginService loginService;
	
	@RequestMapping(value="/loginControl",method={RequestMethod.POST})
	public void login(String userName,String password,HttpSession session,HttpServletRequest request,HttpServletResponse response) throws Exception {
		
		UserCustom userCustom = loginService.loginWithUserName(userName);
//		ModelAndView modelAndView = new ModelAndView();
		
		if(password.equals(userCustom.getPassword())){
			session.setAttribute("userCustom", userCustom);
//			request.getRequestDispatcher("navi.action").forward(request, response);
			response.sendRedirect("welcome.action");
		}else{
//			request.getRequestDispatcher("login.action").forward(request, response);
			response.sendRedirect("login.action");
		}		
//		return modelAndView;
	}
	
	
	
	
	
	
//	public String login(HttpSession session, String userName,String password, UserQueryVo userQueryVo) throws Exception{
//		userQueryVo = loginService.login(userName);
//		if(password.equals(userQueryVo.getUserCustom().getPassword())){
//			session.setAttribute("user", userQueryVo.getUser());
//			return "redirect:navi.action";
//		}
//		return "forward:login.action";
//	}
//	public void login(HttpSession session, HttpServletResponse response,UserQueryVo userQueryVo) throws Exception{
//		String password = userQueryVo.getUserCustom().getPassword();
//		userQueryVo = loginService.login(userQueryVo.getUser().getUserName());
//		if(password.equals(userQueryVo.getUserCustom().getPassword())){
//			session.setAttribute("user", userQueryVo.getUser());
////			request.getRequestDispatcher("navi.action").forward(request, response);
//			response.sendRedirect("navi.action");
//		}else{
//			response.sendRedirect("login.action");
//			
////		request.getRequestDispatcher("login.action").forward(request, response);
//		}
//	}
//	
	
	
	
	
	
	
	
}
