package com.ssc.controller;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.ssc.beans.FilterBean;
import com.ssc.beans.ProjectAttachmentBeanCustom;
import com.ssc.beans.StatusBasicBeanCustom;
import com.ssc.beans.StatusBeanCustom;
import com.ssc.beans.StatusBeanVo;
import com.ssc.beans.UserCustom;
import com.ssc.service.StatusService;

@Controller
public class StatusController {

	@Autowired
	private StatusService statusService;

	@ModelAttribute("projectName")
	public List<StatusBeanCustom> getAllProjectNames(HttpSession session) throws Exception {
		UserCustom userCustom = (UserCustom) session.getAttribute("userCustom");
		Integer groupID = userCustom.getGroupId();
		List<StatusBeanCustom> namesList = statusService.getProjectNames();
		List<StatusBeanCustom> projectName = new ArrayList<StatusBeanCustom>();
		for (StatusBeanCustom allNames : namesList) {
			if (allNames.getGroupId() == groupID) {
				projectName.add(allNames);
			}
		}
		return projectName;
	}

	@RequestMapping(value = "/status", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView statusBrower(HttpSession session, HttpServletRequest request, FilterBean filterBean) throws Exception {
		
		ModelAndView modelAndView = new ModelAndView();
		UserCustom userCustom = (UserCustom) session.getAttribute("userCustom");
		Integer groupID = userCustom.getGroupId();
		
		FilterBean filterBeanFromSession = (FilterBean) session.getAttribute("filerBean");
		
			
//		if (filterBean != null && filterBeanFromSession != null && filterBean.getClass().equals(filterBeanFromSession.getClass()) ){
//			mergeObject(filterBean,filterBeanFromSession);
//		}
		
		// Step 1. Get all projectNames for Filter Form Option
		List<StatusBasicBeanCustom> statusList = statusService.getProjectStausByGroupID(groupID);
		modelAndView.addObject("statusList", statusList);
		Map<String,String> filterStatus = new HashMap<String,String>();
		
		StatusBeanVo statusBeanVo = new StatusBeanVo();
		statusBeanVo.setGroupId(groupID);
		// Step 2. Main Form of Stauts(releaNote)
		setIsCloseIsDeleteIsReverse(filterBean, statusBeanVo);
		setOwnerDateNameStatus(filterBean, statusBeanVo);
		
		if (filterBean.getIsFilter() != null || filterBean.getJobStatus() != null) {
			// * this is filter form
			setFilterStatus(filterBean, modelAndView, statusList, filterStatus);
			//step Add filter Hide columns
			modelAndView.addObject("filterBean", filterBean);
			session.setAttribute("filerBean", filterBean);
		} 
		
		
		List<StatusBeanCustom> statusBeanList = statusService.getStatusByMultiParam(statusBeanVo);
		Set<ProjectAttachmentBeanCustom> attachmentBeanCustomList = new LinkedHashSet<ProjectAttachmentBeanCustom>();
		Integer reviewedCount= 	0;
		//
		for(int i = 0; i < statusBeanList.size(); i++){
			StatusBeanCustom statusBeanCustom = statusBeanList.get(i);
			ProjectAttachmentBeanCustom attachmentBeanCustom = new ProjectAttachmentBeanCustom();
			if(statusBeanCustom.getItemDesc() != null){
				statusBeanCustom.setItemDesc(statusBeanCustom.getItemDesc().replaceAll("\\n", "<br/>"));
				if(statusBeanCustom.getItemDesc().contains("[") && statusBeanCustom.getItemDesc().contains("]")){
					statusBeanCustom.setItemDesc(statusBeanCustom.getItemDesc().replaceAll("\\]", "]</font> "));
					statusBeanCustom.setItemDesc(statusBeanCustom.getItemDesc().replaceAll("\\[", "<font color=\"blue\">["));
				}
				statusBeanList.set(i,statusBeanCustom);
			}
//			if(statusBeanCustom.getLeader()!= null){
//				statusBeanCustom.setLeader(statusBeanCustom.getLeader().replaceAll(";", ";<br/>"));
//				statusBeanList.set(i,statusBeanCustom);
//			}
			if(statusBeanCustom.getStatus() != null){
				statusBeanCustom.setStatus(statusBeanCustom.getStatus().replaceAll("\\n", "<br/>"));
                statusBeanCustom.setStatusInforList(Arrays.asList(statusBeanCustom.getStatus().split("<br/>")));
				statusBeanList.set(i,statusBeanCustom);
			}
			if(statusBeanCustom.getAttachments_url() != null){
				String[] url = statusBeanCustom.getAttachments_url().toUpperCase().split("@@@");
				for(String testcase:url){
					if(testcase.contains("TESTCASE") || testcase.contains("TEST_CASE")){
						statusBeanCustom.setHasTestCase(true);
					}
					if(!testcase.isEmpty()){
						String[] adr = testcase.split("\\|");
						attachmentBeanCustom.setId( Integer.decode(adr[0]));
						attachmentBeanCustom.setProjectId(statusBeanCustom.getId());
						attachmentBeanCustom.setFileName(adr[1]);
						attachmentBeanCustomList.add(attachmentBeanCustom);
					}
				}
			}else{
				statusBeanCustom.setHasTestCase(false);
			}
			String reviewed =null;
			if(statusBeanCustom.getComments() != null){
				if(statusBeanCustom.getComments().contains("[[=ALL REVIEWED=]]")){
					statusBeanCustom.setComments(statusBeanCustom.getComments().replaceAll("\\[\\[=ALL REVIEWED=\\]\\]","<span class=\"reviewTag\" >[[ALL REVIEWED]]</span><br>"));
//					statusBeanCustom.setComments(statusBeanCustom.getComments().replaceAll("\\[\\[","<span class=\"reviewTag\">[["));
//					statusBeanCustom.setComments(statusBeanCustom.getComments().replaceAll("\\]\\]","]]</span><br>"));
					reviewed="reviewed";
					statusBeanCustom.setReviewedTag(reviewed);
				}
				statusBeanCustom.setComments(statusBeanCustom.getComments().replaceAll("\\n", "<br/>"));
				statusBeanList.set(i,statusBeanCustom);
			}
			if(statusBeanCustom.getDbScripts() != null){
				if(statusBeanCustom.getDbScripts().contains("[[=ALL REVIEWED=]]")){
					statusBeanCustom.setDbScripts(statusBeanCustom.getDbScripts().replaceAll("\\[\\[=ALL REVIEWED=\\]\\]","<span class=\"reviewTag\" >[[ALL REVIEWED]]</span><br>"));
					reviewed="reviewed";
					statusBeanCustom.setReviewedTag(reviewed);
				}
				statusBeanCustom.setDbScripts(statusBeanCustom.getDbScripts().replaceAll("\\n", "<br/>"));
				statusBeanList.set(i,statusBeanCustom);
			}
			if(statusBeanCustom.getRemainedQuestions() != null){
				if(statusBeanCustom.getRemainedQuestions().contains("[[=ALL REVIEWED=]]")){
					statusBeanCustom.setRemainedQuestions(statusBeanCustom.getRemainedQuestions().replaceAll("\\[\\[=ALL REVIEWED=\\]\\]","<span class=\"reviewTag\" >[[ALL REVIEWED]]</span><br>"));
					reviewed="reviewed";
					statusBeanCustom.setReviewedTag(reviewed);
				}
				statusBeanCustom.setRemainedQuestions(statusBeanCustom.getRemainedQuestions().replaceAll("\\n", "<br/>"));
				statusBeanList.set(i,statusBeanCustom);
			}
			
			if(statusBeanCustom.getReviewedTag() != null){
				reviewedCount++;
			}
		}
		modelAndView.addObject("reviewedTag", reviewedCount);
		modelAndView.addObject("attachmentBeanCustomList", attachmentBeanCustomList);
		modelAndView.addObject("statusBeanList", statusBeanList);
		modelAndView.addObject("totalRecords", statusBeanList.size());
		
		modelAndView.setViewName("status/status");
		
		return modelAndView;

	}

	/**
	 * @param filterBean
	 * @param modelAndView
	 * @param statusList
	 * @param filterStatus
	 */
	public void setFilterStatus(FilterBean filterBean, ModelAndView modelAndView, List<StatusBasicBeanCustom> statusList, Map<String, String> filterStatus) {
		for(StatusBasicBeanCustom basicStatus:statusList){
			if(Arrays.asList(filterBean.getJobStatus()).contains(basicStatus.getProjectStatus())){
				filterStatus.put(basicStatus.getProjectStatus(), "checked='true'");
			}else{
				filterStatus.put(basicStatus.getProjectStatus(), "");
			}
		}
		modelAndView.addObject("filterStatus", filterStatus);//for jsp checked= true < Job Status:>
	}

	/**
	 * @param filterBean
	 * @param statusBeanVo
	 */
	public void setOwnerDateNameStatus(FilterBean filterBean, StatusBeanVo statusBeanVo) {
		if(filterBean.getOwner() != null){
			statusBeanVo.setUser(filterBean.getOwner());
		}
		if(filterBean.getProdDate() !=null){
			statusBeanVo.setProdDate(filterBean.getProdDate());
		}
		if(filterBean.getProjectName() != null){
			statusBeanVo.setProjectName(filterBean.getProjectName());
		}
//		if(filterBean.getJobStatus()!= null){
//			if(filterBean.getJobStatus().length >= 2 ){
//			statusBeanVo.setJobStatusList(Arrays.asList(filterBean.getJobStatus()));
//			}
//			if(filterBean.getJobStatus().length == 1){
//				statusBeanVo.setJobStatus(filterBean.getJobStatus()[0]);
//			}
//		}
		if(filterBean.getJobStatus()!= null && filterBean.getJobStatus().length != 0){
			statusBeanVo.setJobStatusList(Arrays.asList(filterBean.getJobStatus()));
		}
		
	}

	/**
	 * @param filterBean
	 * @param statusBeanVo
	 */
	public void setIsCloseIsDeleteIsReverse(FilterBean filterBean, StatusBeanVo statusBeanVo) {
		if (filterBean.getIsClose() == null) {
			statusBeanVo.setIsClosed(false);
		} else {
			statusBeanVo.setIsClosed(true);
		}
		if (filterBean.getIsDelete() == null) {
			statusBeanVo.setIsDelete(false);
		} else {
			statusBeanVo.setIsDelete(true);
		}
		if (filterBean.getReverse() == null) {
			statusBeanVo.setIsReverse(false);
		} else {
			statusBeanVo.setIsReverse(true);
		}
	}

	// Using reflect to copy FilterBean each not NULL property from session to filterBean
	/*public static void mergeObject(FilterBean originFilter, FilterBean newFilterFromSession) {
		Field[] fields = newFilterFromSession.getClass().getDeclaredFields();
		for (Field field : fields) {
			try {
				field.setAccessible(true);
				Object value = field.get(newFilterFromSession);
				if (null != value && value.toString().length() != 0) {
					field.set(originFilter, value);
				}
				field.setAccessible(false);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}*/

}
