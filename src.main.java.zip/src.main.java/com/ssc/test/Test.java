package com.ssc.test;


import java.util.Date;

import org.springframework.beans.BeanUtils;

import com.ssc.beans.FilterBean;

public class Test {

	public static void main(String[] args){
//		testCopy();
	}
	
	
	
	
	
}
