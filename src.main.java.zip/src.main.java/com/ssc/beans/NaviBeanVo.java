package com.ssc.beans;

public class NaviBeanVo {

	private NaviBeanCustom naviBeanCustom;
	
	
	
	
	
}
