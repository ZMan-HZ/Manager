package com.ssc.beans;

public class ProjectStatusCustom_NotInUse  extends ProjectStatus_NotInUse{

}
