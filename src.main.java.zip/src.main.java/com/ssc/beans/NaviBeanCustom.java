package com.ssc.beans;

public class NaviBeanCustom extends NaviBean{
	/**
	 * 
	 */

}
