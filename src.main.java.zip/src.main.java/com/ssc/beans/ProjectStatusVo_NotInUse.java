package com.ssc.beans;

import java.util.List;

public class ProjectStatusVo_NotInUse {
	
	private ProjectStatusCustom_NotInUse projectStatusCustoml;
	private ProjectStatus_NotInUse projectStatus;
	private List<ProjectStatusCustom_NotInUse> projectStatusList ;
	
	
	public ProjectStatusCustom_NotInUse getProjectStatusCustoml() {
		return projectStatusCustoml;
	}
	public void setProjectStatusCustoml(ProjectStatusCustom_NotInUse projectStatusCustoml) {
		this.projectStatusCustoml = projectStatusCustoml;
	}
	public ProjectStatus_NotInUse getProjectStatus() {
		return projectStatus;
	}
	public void setProjectStatus(ProjectStatus_NotInUse projectStatus) {
		this.projectStatus = projectStatus;
	}
	public List<ProjectStatusCustom_NotInUse> getProjectStatusList() {
		return projectStatusList;
	}
	public void setProjectStatusList(List<ProjectStatusCustom_NotInUse> projectStatusList) {
		this.projectStatusList = projectStatusList;
	}
	
	
	

}
